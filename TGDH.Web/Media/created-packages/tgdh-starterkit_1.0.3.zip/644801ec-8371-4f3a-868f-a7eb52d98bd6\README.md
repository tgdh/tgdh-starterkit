# Char Limit Property Editor

Umbraco 7.4.3+

- Creates a textbox or textarea based on character limit (textbox for less than 100, and textarea for over 100 characters) that counts the number of characters and blocks further typing of limit is reached.
	Based off the Char Limit Demo from Nibble [http://www.nibble.be/?p=285](http://www.nibble.be/?p=285) but more visually rich.
- Support en-US and pt-BR


Feedback is appreciated
[Carlos Casalicchio](mailto:carlos.casalicchio@gmail.com)